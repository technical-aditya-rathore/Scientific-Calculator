# 💡 Fancy Dark-Themed Scientific Calculator in Python

This is a stylish, feature-rich **Scientific Calculator** built using **Python Tkinter GUI**, designed for Computer Science enthusiasts and developers. It features a **dark theme**, **colorful button UI**, **scientific functions**, and **maximizable window support**.

## 🚀 Features

- ✅ Clean & responsive Tkinter GUI
- 🌑 Dark mode theme with neon-style button colors
- 🧮 Supports advanced scientific operations:
  - Trigonometric (`sin`, `cos`, `tan`)
  - Logarithmic (`log`, `ln`)
  - Square root, exponentiation, factorial
- 🔢 Parentheses and operator support
- 🔄 Maximize window without distortion
- 🚫 Proper error handling

## 🛠️ Built With

- Python 3.x
- Tkinter (Standard GUI Library)
- math module (for scientific functions)

## 📝 How to Run

1. Clone the repo or download the ZIP
2. Ensure Python 3.x is installed
3. Run the script:

```bash
python scientific_calculator.py
```

## 📄 License

This project is open-source under the MIT License.
